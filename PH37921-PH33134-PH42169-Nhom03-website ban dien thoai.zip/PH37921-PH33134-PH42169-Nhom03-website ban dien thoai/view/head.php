<!DOCTYPE html>
<html lang="zxx">
<!-- Mirrored from htmldemo.net/jobaria/jobaria/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 07 Nov 2022 14:12:32 GMT -->

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>Home || mobileX</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" type="text/css" media="screen" href="./src/css/plugins.min.css" />
  <link rel="stylesheet" type="text/css" media="screen" href="./src/css/main.css" />
  <link rel="stylesheet" type="text/css" media="screen" href="./src/css/footer.css" />
  <link rel="stylesheet" type="text/css" media="screen" href="./src/css/dropdown.css" />
  <link rel="shortcut icon" type="./src/imagex-icon" href="./src/image/menu/logo/logo-title-removebg-preview.png" />
  <style type="text/css">
    .error {
      margin-top: 6px;
      margin-bottom: 0;
      color: #fff;
      background-color: #D65C4F;
      display: table;
      padding: 5px 8px;
      font-size: 11px;
      font-weight: 600;
      line-height: 14px;
    }

    .green {
      margin-top: 6px;
      margin-bottom: 0;
      color: #fff;
      background-color: green;
      display: table;
      padding: 5px 8px;
      font-size: 11px;
      font-weight: 600;
      line-height: 14px;
    }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
  <!-- Begin JB's Body Wrapper Area -->
  <div class="wrapper">
    <!-- Begin Loading Area -->
    <!-- <div class="loading">
      <div class="text-center middle">
        <div class="lds-ellipsis">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
    </div> -->
    <!-- Loading Area End Here -->